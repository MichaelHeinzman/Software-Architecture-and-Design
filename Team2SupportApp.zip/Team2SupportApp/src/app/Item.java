package app;

public interface Item {
	public static final String type = "";
	
	public void render();
}
