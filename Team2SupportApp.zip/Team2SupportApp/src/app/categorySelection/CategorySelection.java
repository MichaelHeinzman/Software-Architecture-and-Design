package app.categorySelection;

import app.pageController.Page;

public class CategorySelection implements Page {
    public void render() {
        System.out.println("Rendering Category Selection");
    }
}