package app.pageController;
public interface Page {
    void render();
}
