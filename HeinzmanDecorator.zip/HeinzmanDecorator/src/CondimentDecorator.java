/* 
 * Michael Seth Heinzman
 * Assignment 2
 * Assignment Title: Decorator
 * Class: CSE3421 (Grad Level though)
 */
public abstract class CondimentDecorator extends Beverage{
	public abstract String getDescription();
}
