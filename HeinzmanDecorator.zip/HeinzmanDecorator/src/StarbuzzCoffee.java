/* 
 * Michael Seth Heinzman
 * Assignment 2
 * Assignment Title: Decorator
 * Class: CSE3421 (Grad Level though)
 */

public class StarbuzzCoffee {
	public static void main(String args[]) {
		// Create store object.
        Store store = Store.getInstance();
        store.takeOrders();
	}
}
