/* 
 * Michael Seth Heinzman
 * Assignment 2
 * Assignment Title: Decorator
 * Class: CSE3421 (Grad Level though)
 */
public class HouseBlend extends Beverage{
	public HouseBlend() {
		description = "House Blend Coffee";
	}
	
	public double cost() {
		return .89;
	}
}
