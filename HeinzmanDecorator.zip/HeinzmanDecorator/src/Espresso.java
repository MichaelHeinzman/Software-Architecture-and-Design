/* 
 * Michael Seth Heinzman
 * Assignment 2
 * Assignment Title: Decorator
 * Class: CSE3421 (Grad Level though)
 */
public class Espresso extends Beverage{
	public Espresso () {
		description = "Espresso";
	}
	
	public double cost() {
		return 1.99;
	}
}
