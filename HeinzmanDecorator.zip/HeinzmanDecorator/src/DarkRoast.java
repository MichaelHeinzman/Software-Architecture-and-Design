/* 
 * Michael Seth Heinzman
 * Assignment 2
 * Assignment Title: Decorator
 * Class: CSE3421 (Grad Level though)
 */
public class DarkRoast extends Beverage{
	public DarkRoast () {
		description = "Espresso";
	}
	
	public double cost() {
		return 1.29;
	}
}
